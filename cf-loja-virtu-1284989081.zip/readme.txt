ARQUIVO RETIRADO DE www.novosaber.com
Para a configura��o ideal � s� instalar o bd mysql,que esta no arquivo sql.txt.
Criar um diretorio com o nome de image,pois o upload de imagens da area de administra��o esta
configurado para enviar as figuras para esta pasta.

qualquer duvida enviar email para:novosabe@novosaber.com