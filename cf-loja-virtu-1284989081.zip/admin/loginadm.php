
 <h3>Aqui � o login do Administrador</h3>
<form name="login" method="post" action="confirmar_loginadm.php">
<table width="400" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="150"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Login:</font></td>
<td width="250"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<input name="login" type="text" >
</font></td>
</tr>
<tr>
<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Senha:</font></td>
<td><input type="password" name="senha1" ></td>
</tr>
<tr>
<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
<td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
</tr>
<tr>
<td><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
<input name="entrar" type="submit" value="Entrar">
</font></div></td>
</tr>
</table>
</form>



