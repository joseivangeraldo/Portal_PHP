<form action="upload2.php" method="post"  enctype="multipart/form-data">
Envie sua foto para o site! <input type="file" name="foto"><BR>
<input type="submit" value="Enviar Foto!">
</form
