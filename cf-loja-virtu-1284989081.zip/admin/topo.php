<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Documento sem t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<LINK REL="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
<script language="JavaScript"><!--
function verfonte()
{
if (event.button==2)
{
window.alert('ME HELP.COM. Proibida a c�pia!!')
}
}
document.onmousedown=verfonte
// --></script>
<table width="36%" height="48" border="0">
  <tr> 
    <td align="center"><a href="index.php"><img src="images/home.gif" alt="" width="32" height="32" border="0"><br>
      [Home]</a></td>
    <td align="center"><a href="links.php"><img src="images/mouse.jpg" width="32" height="32" border="0"><br>
      [Links]</a></td>
    <td align="center"><a href="mailto:bonzao@bonzao.cjb.net"><img src="images/faleconosco.gif" width="32" height="32" border="0">[Fale 
      Conosco]</a></td>
    <td align="center"><a href="noticias.php"><img src="images/jornal.gif" width="26" height="24" border="0"><br>
      [Noticias]</a></td>
    <td align="center"><a href="downloads.php"><img src="images/downloads.jpg" width="32" height="32" border="0"><br>
      [Downloads]</a></td>
    <td align="center"><a href="upload.php"><img src="images/enviararquivos.gif" width="32" height="32" border="0">[Arquivos]</a></td>
    <td align="center"><a href="materia.php"><img src="images/materia.gif" width="32" height="32" border="0">[Mat�ria]</a></td>
  </tr>
</table>
</body>
</html>
