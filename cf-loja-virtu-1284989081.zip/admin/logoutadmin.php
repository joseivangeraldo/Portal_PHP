<?
session_unset();
 session_destroy() ;


echo " Saiu do sistema corretamente <a href=\"../index.php\">voltar para pagina inicial</a> ";
?>
