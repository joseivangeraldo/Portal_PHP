
<form name="form1" method="post" action="loga.php?acao=logar">
Login: <input type="text" name="nome"><BR>
Senha: <input type="password" name="pwd"><BR>
<input type="submit">
</form
